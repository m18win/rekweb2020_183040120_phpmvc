<?php 


class Controller { // ini merupakan kelas utama dari folder controllers yang akan menjadi extands
	
	public function view($view, $data = [])
	{
		require_once '../app/views/' . $view . '.php';
	}

	public function model ($model)
	{
		require_once '../app/models/' . $model . '.php';
		return new $model;
	}
}