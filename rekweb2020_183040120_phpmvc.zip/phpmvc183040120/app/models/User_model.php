<?php 

class User_model {
	
	private $nama = 'Muhamad Aswin';

	public function getUser()
	{
		return $this->nama;
	}
}